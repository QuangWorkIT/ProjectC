#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "seat.h"
// int main() {
//   Seat seats[100] ; //ban dau kh co ghe
//   int numSeats = 0; //so luong ghe hien co
  
//   while (1) {
//     int choice;

//     printf("\nSeat Management System\n");
//     printf("1. Create Seat\n");
//     printf("2. Add Seat\n");
//     printf("3. Delete Seat\n");
//     printf("4. Modify Seat\n");
//     printf("4. Exit\n");
//     printf("Enter your choice: ");
//     scanf("%d", &choice);

//     switch (choice) {
//       case 1:
//         createSeat(&seats, &numSeats );
//         break;
//       case 2:
//         addSeat(seats, &numSeats);
//         break;
//       case 3:
//         deleteSeat(seats, &numSeats);
//         break;
//       case 4:
//         modifySeat(seats, &numSeats);
//         break;
//       case 5:
//          printf("exit the program.\n");
//          default:
//          printf("Invalid selection, please select again");
// } while (choice != 5);
// free(seats);
// return 0;
//   }
// }


int main() {
    Seat seats[100]; // Array of seats
    int numSeats = 0; // Number of seats currently present

    while (1) {
        int choice;

        printf("\nSeat Management System\n");
        printf("1. Create Seat\n");
        printf("2. Add Seat\n");
        printf("3. Delete Seat\n");
        printf("4. Modify Seat\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                createSeat(seats, &numSeats);
                break;
            case 2:
                addSeat(seats, &numSeats);
                break;
            case 3:
                deleteSeat(seats, &numSeats);
                break;
            case 4:
                modifySeat(seats, &numSeats);
                break;
            case 5:
                printf("Exiting the program.\n");
                return 0;
            default:
                printf("Invalid selection, please select again.\n");
        }
    }
    return 0;
}
