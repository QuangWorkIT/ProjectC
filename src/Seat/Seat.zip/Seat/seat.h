#ifndef SEAT_H
#define SEAT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_FLIGHT 100
#define MAX_DESTINATION 50
#define MAX_AIRLINE 50
#define MAX_FLIGHT_STATUS 50
#define MAX_AIRLINE 50
#define MAX_TIME 10
#define MAX_PASSENGER_INFO 100
#define MAX_SEAT_NUMBER 50
typedef struct Seat {
    int seatNumber;
     char status[20]; //trạng thái ghế ha(trống, đã đặt)  

} Seat;

typedef struct
{
    char destination[MAX_DESTINATION];
    char departure[MAX_DESTINATION];
    char takeoff_time[MAX_TIME];
    char landing_time[MAX_TIME];
    char airline[MAX_AIRLINE];
    char flight_time[MAX_TIME];
    char status[MAX_FLIGHT_STATUS];
} Flight;

typedef struct 
{
    char buyer_info[MAX_PASSENGER_INFO];
    char booking_time[MAX_TIME];
    float price;
    char classification[MAX_AIRLINE];
    char flight_number[MAX_AIRLINE];
    char seat_number[MAX_TIME];
    char ticket_id[MAX_PASSENGER_INFO];
} Ticket;

void Flight_create(Flight flight[], int *current_id);
void Flight_remove(Flight flight[], int *current_id);
void Flight_list(Flight flight[], int *current_id);

void createSeat(Seat *seats, int *numSeats);
void addSeat(Seat *seats, int *numSeats);
void deleteSeat(Seat *seats, int *numSeats);
void modifySeat(Seat *seats, int *numSeats);

void create_ticket(Ticket tickets[], int *current_id);
void remove_ticket(Ticket tickets[], int *current_id);
void save_data(Ticket tickets[], int *current_id);
void showAll(Ticket tickets[], int *current_id);



#endif