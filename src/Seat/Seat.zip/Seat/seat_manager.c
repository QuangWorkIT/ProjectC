#include "seat.h"
#include <string.h>

// void createSeat(Seat *seats[100], int *numSeats) {
//     printf("Enter the seat number: ");
//     scanf("%d", &((seats)[*numSeats ]->seatNumber));
//     printf("Enter the status of the chair: ");
//     scanf(" %[^\n]s", &(seats)[*numSeats ]->status);
//     printf("Seat added successfully.\n");
//     *numSeats++;
// }

// void addSeat(Seat *seats[100], int *numSeats) {
//     createSeat(&seats[100], numSeats);  
// }


// void deleteSeat(Seat *seats, int *numSeats) {
//     if (*numSeats == 0) {
//         printf("There are no seats to clear\n");
//         return;
//     }
//      (*numSeats)--;
//      seats = (Seat *)realloc(seats, (*numSeats) * sizeof(Seat));
//     printf("Seat deleted successfully\n");
// }

// void modifySeat(Seat *seats, int *numSeats) {
//     int seatNumber;
//     printf("Enter the serial number of the chair that needs change: ");
//     scanf("%d", &seatNumber);

//     int found = 0;
//     for (int i = 0; i < *numSeats; i++) {
//         if (seats[i].seatNumber == seatNumber) {
//             printf("Nhap trang thai moi cua ghe: ");
//             scanf(" %[^\n]s", seats[i].status);
//             printf("Seat information modified successfully.\n");
//             found = 1;
//             break;
//         }

//     }
//     if(found==0) 
//         printf("not found seat number");
// }


void createSeat(Seat *seats, int *numSeats) {
    printf("Enter the seat number: ");
    scanf("%d", &seats[*numSeats].seatNumber);
    printf("Enter the status of the chair: ");
    scanf(" %[^\n]", seats[*numSeats].status);
    printf("Seat added successfully.\n");
    (*numSeats)++;
}

void addSeat(Seat *seats, int *numSeats) {
    createSeat(seats, numSeats);
}

void deleteSeat(Seat *seats, int *numSeats) {
    if (*numSeats == 0) {
        printf("There are no seats to clear\n");
        return;
    }
    (*numSeats)--;
    printf("Seat deleted successfully\n");
}

void modifySeat(Seat *seats, int *numSeats) {
    int seatNumber;
    printf("Enter the serial number of the chair that needs change: ");
    scanf("%d", &seatNumber);

    int found = 0;
    for (int i = 0; i < *numSeats; i++) {
        if (seats[i].seatNumber == seatNumber) {
            printf("Enter the new status of the seat: ");
            scanf(" %[^\n]", seats[i].status);
            printf("Seat information modified successfully.\n");
            found = 1;
            break;
        }
    }
    if (found == 0) 
        printf("Seat with seat number %d not found.\n", seatNumber);
}
